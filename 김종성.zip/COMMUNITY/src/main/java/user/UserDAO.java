package user;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDAO {
	
	
 private Connection conn;
 private PreparedStatement pstmt;
 private ResultSet rs;
 
 
 public UserDAO() {
	 try {
		  String dbURL = "jdbc:mysql://localhost:3306/Project?characterEncoding=UTF-8&serverTimezone=UTC";
          String dbID = "root";                       //mysql 접속 id
          String dbPassword = "Jong_0919!!";            //mysql 접속 비밀번호
          Class.forName("com.mysql.jdbc.Driver");  //드라이버 인터페이스를 구현한 클래스를 로딩
          conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
          System.out.println("UserDAO 연결직후");
      } catch (Exception e) {
          e.printStackTrace();
      }
  }
 
 
 public int join(User user) {
	 String SQL = "INSERT INTO User VALUES(?,?,?,?,?,?,?)";
	 try {
		 pstmt = conn.prepareStatement(SQL);
		 pstmt.setInt(1, user.getUser_id());
		 pstmt.setString(2, user.getPassword());
		 pstmt.setString(3, user.getUserid());
		 pstmt.setString(4, user.getEmail());
		 pstmt.setString(5, user.getNicname());
		 pstmt.setString(6, user.getCreate_date());
		 pstmt.setString(7, user.getUserid());
		
	
		 
		 return pstmt.executeUpdate();
		 
	 } catch(Exception e) {
		 e.printStackTrace();
	 } 
	 return -1 ; // database error
 }
 
 public int login(String userid , String password) {
	 String SQL = "SELECT password FROM User WHERE userid = ?";
	 try {
		 pstmt =  conn.prepareStatement(SQL);
		 pstmt.setString(1, userid);
		 rs = pstmt.executeQuery();
		 
		 if ( rs.next()) {
			 if(rs.getString(1).equals(password)) 
				 return 1; // 로그인성공
			 else
				 return 0; // 비밀번호 불일치
			 }
		 
		 
		 return -1 ;  // 아이디가없음
		 }
	 catch ( Exception e) {
		 e.printStackTrace();
	 } return -2 ; // 데이터베이스 종
 }
 
}



