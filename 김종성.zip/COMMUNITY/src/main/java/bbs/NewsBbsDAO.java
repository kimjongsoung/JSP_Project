//https://www.bootdey.com/snippets/view/projects-dashboard//
//bbs template 


package bbs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class NewsBbsDAO {

	 private Connection conn;
		
	 private ResultSet rs;
	 
	 
	 public NewsBbsDAO() {
		 try {
			  String dbURL = "jdbc:mysql://localhost:3306/Project?characterEncoding=UTF-8&serverTimezone=UTC";
              String dbID = "root";                       //mysql 접속 id
              String dbPassword = "Jong_0919!!";            //mysql 접속 비밀번호
              Class.forName("com.mysql.cj.jdbc.Driver");  //드라이버 인터페이스를 구현한 클래스를 로딩
              conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
              System.out.println("UserDAO 연결직후");
          } catch (Exception e) {
              e.printStackTrace();
          }
		 // 여기까지가 접속할수있게 해주는 부분
	 }
	 
	
	 
	 
}
